#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$BASE"
export PYTHONPATH="$BASE/src"
exec python3 "$BASE/src/main.py"
